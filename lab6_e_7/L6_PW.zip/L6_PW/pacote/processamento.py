def e_positivo(n):
    # Assume-se aqui também que 0 já é positivo (facilmente se adapta a funcao caso esteja errado)
    return n >= 0


def e_par(n):
    return n % 2 == 0
