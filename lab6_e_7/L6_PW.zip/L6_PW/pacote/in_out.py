def ler_numero():
    try:
        num = int(input('Insira um inteiro entre 1 e 10: '))
        return num
    except:
        # Erro de leitura, devolve um numero negativo arbitrario
        return -10000


def imprime_resultados(n, positivo, par):
    msgPositivo = 'positivo' if positivo else 'negativo'
    msgPar = 'par' if par else 'impar'
    print(f'O numero {n} e {msgPositivo} e {msgPar}')